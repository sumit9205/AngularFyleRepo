# AngularFyleRepo
api handling 


Repo service is created to write the api call function.
dataModel.ts file is used to define the types of objects.
Loader component is made inside the code.
Repo description component is made which is rendered lots of times in the DOM.
