export interface RepoDetails {
    name: string;
    description: string;
    topics: String[];
}
